package com.ctsi.config;

/**
 * @ClassName : DataSourceConstant
 * @Description :
 * @Author : Xiaotianyu
 */
public class DataSourceConstant {
    public static final String READ_DATASOURCE = "master";
    public static final String Write_DATASOURCE = "write";
    public static final String SINGLE_DATASOURCE = "master";
}
