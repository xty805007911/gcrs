package com.ctsi.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ctsi.entity.TbOrder;

@Repository
public interface TbOrderMapper extends BaseMapper<TbOrder> {
	
}