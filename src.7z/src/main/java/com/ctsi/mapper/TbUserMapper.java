package com.ctsi.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ctsi.entity.TbUser;

@Repository
public interface TbUserMapper extends BaseMapper<TbUser> {
	
}