package com.ctsi.mapper;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ctsi.entity.TbRole;

@Repository
public interface TbRoleMapper extends BaseMapper<TbRole> {
	
}