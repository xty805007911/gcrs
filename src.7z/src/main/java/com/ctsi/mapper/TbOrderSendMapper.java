package com.ctsi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ctsi.entity.TbOrderSend;
import org.springframework.stereotype.Repository;

@Repository
public interface TbOrderSendMapper extends BaseMapper<TbOrderSend> {
	
}